// bien évidemment, ce sont des faux identifiants
const variables = {
    OVH_API_SERVER: "ovh-fr",
    OVH_API_KEY: "d922a6fcf4a9165a",
    OVH_API_SECRET: "faccd4240c9928ac42fbd4e9f929abbc"
}
