# vulnerableProject

Ce projet est un template utilisé pour le cours d'Approche Qualité en Développement Logiciel.

Celui-ci nous a servi à présenter de nombreux outils internes à Github pouvant notamment détecter des problèmes et vulnérabilités dans le projet, et mettre en place des solutions automatisés.
